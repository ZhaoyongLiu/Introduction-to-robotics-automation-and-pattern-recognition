# File description

1. run  "Solving_LMI.m"  to obtain parameters that meet the conditions.

2. run "Main.m" to get the state trajectory.
