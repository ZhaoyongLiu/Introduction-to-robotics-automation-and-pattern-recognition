%%
%  先运行SLS_Simu.slx文件获取系统状态轨迹，然后运行SimuPlot.m文件进行绘图