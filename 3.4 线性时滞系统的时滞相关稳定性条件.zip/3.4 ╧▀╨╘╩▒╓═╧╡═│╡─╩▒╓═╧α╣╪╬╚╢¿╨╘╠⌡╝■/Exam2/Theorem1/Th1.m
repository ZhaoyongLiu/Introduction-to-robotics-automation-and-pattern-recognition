%% LMI for Theorem 1
% Reference: https://zhuanlan.zhihu.com/p/607642466
% Author: Liu Zhaoyong
% Date:2023.2.20  Version 1.0: Coding
%%
clc;clearvars 
LMIs=6; % LMI个数
h=0.9997;
mu=1;
A=[-2 0;0 -0.9]; Ad=[-1 0;-1 -1]; % 系统矩阵
dimn=length(A);

%%
setlmis([]) 
P = lmivar(1,[dimn 1]); % 定义变量P
Q = lmivar(1,[dimn 1]);
Z = lmivar(1,[dimn 1]);

X11 = lmivar(2,[dimn dimn]);
X12 = lmivar(2,[dimn dimn]);
X22 = lmivar(2,[dimn dimn]);

N1 = lmivar(2,[dimn dimn]);
N2 = lmivar(2,[dimn dimn]);

%% LMI #1
lmiterm([1 1 1 P],1,A,'s'); 
lmiterm([1 1 1 N1],1,1,'s');
lmiterm([1 1 1 Q],1,1);
lmiterm([1 1 1 X11],h,1);

lmiterm([1 1 2 P],1,Ad); 
lmiterm([1 1 2 N1],-1,1);
lmiterm([1 1 2 -N2],1,1);
lmiterm([1 1 2 X12],h,1);

lmiterm([1 2 2 N2],-1,1,'s'); 
lmiterm([1 2 2 Q],-(1-mu),1); 
lmiterm([1 2 2 X22],h,1);

lmiterm([1 1 3 Z],h*A',1);
lmiterm([1 2 3 Z],h*Ad',1);
lmiterm([1 3 3 Z],-h,1);

%%
lmiterm([-2 1 1 X11],1,1); 
lmiterm([-2 1 2 X12],1,1); 
lmiterm([-2 2 2 X22],1,1); 
lmiterm([-2 1 3 N1],1,1); 
lmiterm([-2 2 3 N2],1,1); 
lmiterm([-2 3 3 Z],1,1); 
%%
lmiterm([-3 1 1 P],1,1); 
%%
lmiterm([-4 1 1 Q],1,1); 
%%
lmiterm([-5 1 1 Z],1,1); 
%%
lmiterm([-6 1 1 X11],1,1); 
lmiterm([-6 1 2 X12],1,1); 
lmiterm([-6 2 2 X22],1,1); 
%% LMI求解
lmis = getlmis;
[tmin,xfeas] = feasp(lmis,[0,0,10,0,0],0); % 使用feasp函数求解
% [tmin,xfeas] = feasp(lmis);
P = dec2mat(lmis,xfeas,P); %使用dec2mat从xfeas导出矩阵变量的可行值
Q = dec2mat(lmis,xfeas,Q);
Z = dec2mat(lmis,xfeas,Z);
X11 = dec2mat(lmis,xfeas,X11);
X12 = dec2mat(lmis,xfeas,X12);
X22 = dec2mat(lmis,xfeas,X22);
N1 = dec2mat(lmis,xfeas,N1);
N2 = dec2mat(lmis,xfeas,N2);
disp('P = ');disp(P);

%% 检验求得的Xopt是否满足线性矩阵不等式约束  *************
evlmi=evallmi(lmis,xfeas); % 将求解的xfeas带入LMI中
Lhs=cell(1,LMIs);Rhs=cell(1,LMIs);
Lhs_Rhs=cell(1,LMIs);
%------------------------------------------检验每一个LMI的负定性
sum=0;label=zeros(1,LMIs);
store=cell(1,LMIs); % 记录各个LMI的左右特征值之差
for i=1:LMIs
    [lhs,rhs]=showlmi(evlmi,i);
    Lhs{1,i}=lhs;Rhs{1,i}=rhs;
    Lhs_Rhs{1,i}=[lhs,rhs];
    store{1,i}=eig(lhs-rhs);
    if(eig(lhs-rhs)<0)
        sum=sum+1;
        label(i)=1;
    end
end
if(sum==LMIs)
    disp('****** All LMIs are negative definite! ******');
else
    disp('****** Error! ******');
    notsat_num=find(label==0);
    for j=1:length(notsat_num)
        fprintf('The %dth LMI is infeasible!\n',notsat_num(j));
    end
end